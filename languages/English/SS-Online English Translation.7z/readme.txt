English translation 1.0
Works only for v1.6.1